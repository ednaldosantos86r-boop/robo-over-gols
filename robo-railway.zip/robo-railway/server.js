const https = require('https');
const http = require('http');

let config = {
  apiKey: process.env.API_KEY || '',
  botToken: process.env.BOT_TOKEN || '',
  chatId: process.env.CHAT_ID || '',
};

const seenIds = new Set();

function analyzeMatch(match) {
  const goals = match.score.split('-').reduce((a,b)=>parseInt(a)+parseInt(b),0);
  const off = match.stats.offensive[0]+match.stats.offensive[1];
  const shots = match.stats.shots[0]+match.stats.shots[1];
  const onTarget = match.stats.onTarget[0]+match.stats.onTarget[1];
  const corners = match.stats.corners[0]+match.stats.corners[1];
  const min = match.minute;
  let pts=0, reasons=[];
  if(min>=55&&min<=80){pts+=25;reasons.push('Janela ideal (55-80min)');}
  if(off>=65){pts+=20;reasons.push('Alta pressao ('+off+')');}
  if(shots>=12){pts+=20;reasons.push('Muitos arremates ('+shots+')');}
  if(onTarget>=5){pts+=15;reasons.push('No alvo ('+onTarget+')');}
  if(goals===1){pts+=10;reasons.push('Placar aberto');}
  if(goals===0&&min>=60){pts+=15;reasons.push('0x0 tardio');}
  if(corners>=5){pts+=10;reasons.push('Escanteios ('+corners+')');}
  const score=Math.min(pts,100);
  let level='BAIXO';
  if(score>=70) level='QUENTE';
  else if(score>=45) level='MEDIO';
  return{score,level,reasons};
}

function sendTelegram(text) {
  return new Promise((resolve) => {
    if (!config.botToken || !config.chatId) { resolve(false); return; }
    const body = JSON.stringify({ chat_id: config.chatId, text, parse_mode: 'HTML' });
    const options = {
      hostname: 'api.telegram.org',
      path: '/bot'+config.botToken+'/sendMessage',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    };
    const req = https.request(options, (res) => { resolve(res.statusCode === 200); });
    req.on('error', () => resolve(false));
    req.write(body);
    req.end();
  });
}

function fetchLive() {
  return new Promise((resolve) => {
    if (!config.apiKey) { resolve([]); return; }
    const options = {
      hostname: 'v3.football.api-sports.io',
      path: '/fixtures?live=all',
      method: 'GET',
      headers: { 'x-apisports-key': config.apiKey }
    };
    let data = '';
    const req = https.request(options, (res) => {
      res.on('data', chunk => data += chunk);
      res.on('end', () => { try { resolve(JSON.parse(data).response || []); } catch { resolve([]); } });
    });
    req.on('error', () => resolve([]));
    req.end();
  });
}

function fetchStats(fixtureId) {
  return new Promise((resolve) => {
    const options = {
      hostname: 'v3.football.api-sports.io',
      path: '/fixtures/statistics?fixture='+fixtureId,
      method: 'GET',
      headers: { 'x-apisports-key': config.apiKey }
    };
    let data = '';
    const req = https.request(options, (res) => {
      res.on('data', chunk => data += chunk);
      res.on('end', () => { try { resolve(JSON.parse(data).response || []); } catch { resolve([]); } });
    });
    req.on('error', () => resolve([]));
    req.end();
  });
}

function convertFixture(fix) {
  const s = fix.statistics || [];
  const g = (ti, name) => parseInt((s[ti]&&s[ti].statistics||[]).find(x=>x.type===name)||{value:0}).value||0;
  const hs=g(0,'Total Shots'), as2=g(1,'Total Shots'), hp=g(0,'Ball Possession')||50;
  return {
    id: fix.fixture&&fix.fixture.id,
    league: (fix.league&&fix.league.name)||'Liga',
    home: (fix.teams&&fix.teams.home&&fix.teams.home.name)||'Casa',
    away: (fix.teams&&fix.teams.away&&fix.teams.away.name)||'Fora',
    minute: (fix.fixture&&fix.fixture.status&&fix.fixture.status.elapsed)||0,
    score: ((fix.goals&&fix.goals.home)||0)+'-'+((fix.goals&&fix.goals.away)||0),
    stats: {
      offensive: [hs*5, as2*5],
      corners: [g(0,'Corner Kicks'), g(1,'Corner Kicks')],
      shots: [hs, as2],
      onTarget: [g(0,'Shots on Goal'), g(1,'Shots on Goal')],
      possession: [hp, 100-hp],
    }
  };
}

async function checkSignals() {
  console.log('['+new Date().toLocaleTimeString('pt-BR')+'] Verificando partidas...');
  try {
    const fixtures = await fetchLive();
    const live = fixtures.filter(f => (f.fixture&&f.fixture.status&&f.fixture.status.elapsed||0) >= 30).slice(0, 8);
    for (const fix of live) {
      const stats = await fetchStats(fix.fixture.id);
      const match = convertFixture({ ...fix, statistics: stats });
      const analysis = analyzeMatch(match);
      if (analysis.level === 'QUENTE' && !seenIds.has(match.id)) {
        seenIds.add(match.id);
        const msg = '🔥 <b>SINAL QUENTE!</b>\n\n🏆 '+match.league+'\n⚽ <b>'+match.home+' v '+match.away+'</b>\n⏱ '+match.minute+"' | Placar: "+match.score+'\n📊 Score: '+analysis.score+'/100\n\n✅ '+analysis.reasons.join(', ')+'\n\n🎯 <b>APOSTAR: Mais 1 Gol</b>\n\n⚠️ Jogue com responsabilidade.';
        const ok = await sendTelegram(msg);
        console.log('🔥 Sinal: '+match.home+' v '+match.away+' - '+(ok?'ENVIADO':'ERRO'));
      }
    }
    console.log('Verificado '+live.length+' partidas.');
  } catch(e) { console.error('Erro:', e.message); }
}

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }
  if (req.method === 'POST' && req.url === '/config') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        if (data.apiKey) config.apiKey = data.apiKey;
        if (data.botToken) config.botToken = data.botToken;
        if (data.chatId) config.chatId = data.chatId;
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify({ ok: true }));
        console.log('Config atualizada! Iniciando verificacao...');
        setTimeout(checkSignals, 2000);
      } catch { res.writeHead(400); res.end('Erro'); }
    });
  } else if (req.url === '/status') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end(JSON.stringify({ ok: true, configured: !!(config.apiKey && config.botToken && config.chatId), sinais: seenIds.size }));
  } else {
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
    res.end('<h1>🤖 Robo Over Gols rodando!</h1><p>Status: '+( config.apiKey ? 'Configurado' : 'Aguardando configuracao')+'</p>');
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('🤖 Robo Over Gols na porta '+PORT);
});

setInterval(checkSignals, 5 * 60 * 1000);
setTimeout(checkSignals, 10000);
